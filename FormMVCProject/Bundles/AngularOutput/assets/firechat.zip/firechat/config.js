var hostname = window.location.host, _chat_ref;

if(hostname === 'localhost'){
    // Development Environment
    _chat_ref = "firechat";
    
    // Initialize Firebase
    var config = {
        apiKey: "AIzaSyCx9FibkbvZusjJpobFb1AkcG4YASEJ2-A",
        authDomain: "form-generator-89e14.firebaseapp.com",
        databaseURL: "https://form-generator-89e14.firebaseio.com",
        projectId: "form-generator-89e14",
        storageBucket: "form-generator-89e14.appspot.com",
        messagingSenderId: "887737447775"
    };
}else{
    // Production Environment
    _chat_ref = "formbuilder";
    
    // Initialize Firebase
    var config = {
        apiKey: "AIzaSyCx9FibkbvZusjJpobFb1AkcG4YASEJ2-A",
        authDomain: "form-generator-89e14.firebaseapp.com",
        databaseURL: "https://form-generator-89e14.firebaseio.com",
        projectId: "form-generator-89e14",
        storageBucket: "form-generator-89e14.appspot.com",
        messagingSenderId: "887737447775"
    };
}

firebase.initializeApp(config);

// Firebase queue summary update
var chatRef = firebase.database().ref(_chat_ref);
// Create a new ref and log it’s push key
var queueRef = chatRef.child('queue-summary');
function sendFiberNotificaton(ajaxUrl, firebase_room_id, postData){
    if(postData !== '') {
        $.ajax({
            type: "POST",
            url: ajaxUrl,
            data: JSON.parse(postData),
            dataType: 'json',
            success: function( response ) {
                queueRef.push({
                    roomId: firebase_room_id,
                    summary: response
                });
            }
        });
    } else {
        queueRef.push({
            roomId: firebase_room_id
        });
    }
}

function getAllValidationMessages(messages) {
    var result = [];
    $.each(messages, function(field, errors) {
        if(errors.length > 1) {
            $.each(errors, function(field, error) {
                result.push(error);
            });
        } else {
            result.push(errors);
        }        
    });
    return result;
}

function sendChatFiberNotificaton(ajaxUrl, postData){
    $.ajax({
        type: "POST",
        url: ajaxUrl,
        data: postData,
        dataType: 'json',
        success: function( response ) {

        }
    });
}

queueRef.limitToLast(1).on('child_added', function (snapshot) {
    var queueSummary = snapshot.val();
    var summaryKey = snapshot.key;
    //console.log(queueSummary);
    if(queueSummary['summary']){
        updateQueueSummary(queueSummary['summary']);
    } else {
        $('body .refresh-summary').click();
    }
    queueRef.child(summaryKey).remove();
    //
});

function updateQueueSummary(response){    
    $('div.alert.calling-messages').html('');
    $.each(response, function(key, data){
        //console.log(key, data);
        if(typeof data !== 'undefined'){
            if(key < 3){
                $.each(data, function(name, value){
                    if(name !== 'status'){
                        $('div#' + name + ' span.' + data.status).text(value);
                    }
                });
            }else if(key === 3){
                //$.each(data, function(queue_slug, calling_records){
                $('body .grid-item').each(function(){
                    var queue_slug = $(this).attr('id');
                    if(typeof data[queue_slug] !== 'undefined'){
                        var calling_records = data[queue_slug];
                        if(calling_records.length > 0) {
                            if($('div#' + queue_slug + ' table').length){
                                var $table = $('div#' + queue_slug + ' table');
                                $table.find('tbody').remove();
                                var $tbody = $("<tbody>");
                                $table.append($tbody);

                                var tbody = '';                                            
                                calling_records.forEach(function(record){
                                    tbody += '<tr>';
                                    tbody += '<td>' + record['token-number'] + '</td>';
                                    if(typeof record['queue-server'] !== 'undefined')
                                        tbody += '<td>' + record['queue-server'] + '</td>';
                                    tbody += '</tr>';
                                });

                                $tbody.append(tbody);
                            }else{
                                var $html = $('<h3 class="name calling-head">Calling Numbers:</h3>');
                                var $table = $("<table>",{'style':'width:100%; color:inherit;'});
                                var $tbody = $("<tbody>");
                                $table.append($tbody);

                                var tbody = '';                                            
                                calling_records.forEach(function(record){
                                    tbody += '<tr>';
                                    tbody += '<td>' + record['token-number'] + '</td>';
                                    if(typeof record['queue-server'] !== 'undefined')
                                        tbody += '<td>' + record['queue-server'] + '</td>';
                                    tbody += '</tr>';
                                });

                                $tbody.append(tbody);
                                $html.insertAfter( $('div#' + queue_slug + ' > div.symbol') );
                                $table.insertAfter( $('div#' + queue_slug + ' > h3.calling-head') );
                            }
                            if($('div#' + queue_slug + ' > h3 span.my-tickets').length){
                                var my_tickets_str = $('div#' + queue_slug + ' > h3 span.my-tickets').text();
                                if(my_tickets_str !== 'None'){
                                    var myTickets = my_tickets_str.split(', ');
                                    if(myTickets.length){                                                    
                                        showCallingMessages(myTickets, data[queue_slug]);
                                    }
                                }
                            }                                        
                        }else{
                            $('div#' + queue_slug + ' > h3.calling-head').remove();
                            $('div#' + queue_slug + ' > table').remove();
                        }
                    }else{
                        $('div#' + queue_slug + ' > h3.calling-head').remove();
                        $('div#' + queue_slug + ' > table').remove();
                    }
                });
            }else if(key === 4){
                $('.summary-update-time').text(data);
            }
        }else{
            $('body .grid-item').each(function(){
                var queue_slug = $(this).attr('id');
                $('div#' + queue_slug + ' > h3.calling-head').remove();
                $('div#' + queue_slug + ' > table').remove();
                $('div.alert.calling-messages').remove();
            });
        }
    });
}
//console.log(hostname,':', _chat_ref);
$(document).ready(function(){
    if($('body').find('ol.breadcrumb').length === 0){
        $('nav.navbar').css('margin-top', '26px');
    }
});

//*******************************************************//
//packery menu creation
$(document).on('click','#redirectMenuPage',function(){
    var menuName= $('#menuName').text();
    var menuDescription= $('#menuDescription').text();
    var matches = menuName.match(/\b(\w)/g);
    var acronym = matches.join('');
    if(acronym.length==1){
        var short_name=menuName.substring(0, 3).toUpperCase();
    }else{
        var short_name=acronym.substring(0, 3).toUpperCase();
    }
    var urlpath = $('#getRedirectUrl').text();
    var csrf_token = $('#csrf_token').text();
    
    if(window.location.href.indexOf('groups') >0 || window.location.href.indexOf('user-forms') >0){
       var type="Group";
       var color="#f67a00";
    }else if(window.location.href.indexOf('chat') >0){
        var type="ChatRoom";
        var color="#00ffff";
    }else if(window.location.href.indexOf('user-forms') >0 || window.location.href.indexOf('savedata') >0 || window.location.href.indexOf('records') >0){
        var type="Form";
        var color="#008000";
    }else if(window.location.href.indexOf('users') >0){
        var type="Contact";
        var color="#a90600";
    }else if(window.location.href.indexOf('application') >0){
        var type="Application";
        var color="#ffff00";
    }else if(window.location.href.indexOf('settings') >0){
        var type="Settings";
        var color="#ffa07a";
    }else if(window.location.href.indexOf('summary') >0){
        var type="Summary";
        var color="#E5CCFF";
    }else if(window.location.href.indexOf('queue') >0){
        var type="Queue";
        var color="#E5FFCC";
    }
    var menuLink,menuPath;
    var f = document.createElement("form");
    f.setAttribute('method',"post");
    f.setAttribute('id',"redirect_form");
    f.setAttribute('class',"hidden");
    f.setAttribute('action',urlpath);
    //for hidden token
    var a = document.createElement("input"); 
    a.setAttribute('type',"hidden");
    a.setAttribute('name',"_token");
    a.setAttribute('value',csrf_token);
    //for image link
    if((menuLink=document.getElementById('menuRedirectLink')) && (menuPath=document.getElementById('menuRedirectPath'))){
     var b = document.createElement("input"); 
        b.setAttribute('type',"text");
        b.setAttribute('name',"icon");
        b.setAttribute('value',menuLink.innerHTML);
        f.append(b); 
     var c = document.createElement("input"); 
        c.setAttribute('type',"text");
        c.setAttribute('name',"menuRedirectPath");
        c.setAttribute('value',menuPath.innerHTML);
        f.append(c); 
    }
    //for name
    var i = document.createElement("input"); 
    i.setAttribute('type',"text");
    i.setAttribute('name',"name");
    i.setAttribute('value',menuName);
    //for description
    var j = document.createElement("input");
    j.setAttribute('type',"textarea");
    j.setAttribute('name',"description");
    j.setAttribute('value',JSON.stringify('<p>'+menuDescription+'</p>'));
    //for short_name
    var k = document.createElement("input");
    k.setAttribute('type',"text");
    k.setAttribute('name',"short_name");
    k.setAttribute('value',short_name);
    //for type
    var l = document.createElement("input"); 
    l.setAttribute('type',"text");
    l.setAttribute('name',"type");
    l.setAttribute('value',type);
    //for link
    var m = document.createElement("input");
    m.setAttribute('type',"text");
    m.setAttribute('name',"link");
    m.setAttribute('value',window.location.href);
    //for original_size
    var n = document.createElement("input"); 
    n.setAttribute('type',"text");
    n.setAttribute('name',"original_size");
    n.setAttribute('value','1x1');
    //for expanded_size
    var o = document.createElement("input"); 
    o.setAttribute('type',"text");
    o.setAttribute('name',"expanded_size");
    o.setAttribute('value','3x3');
    //for color
    var p = document.createElement("input");
    p.setAttribute('type',"text");
    p.setAttribute('name',"color");
    p.setAttribute('value',color);

    var s = document.createElement("input"); 
    s.setAttribute('type',"submit");
    s.setAttribute('value',"Submit");

    f.appendChild(a);f.appendChild(i);f.appendChild(j);f.appendChild(k);f.appendChild(l);
    f.appendChild(m);f.appendChild(n);f.appendChild(o);f.appendChild(p);f.appendChild(s);
    document.body.appendChild(f);
    //console.log(f);
//    alert();
    f.submit();
    return false;
});
//*********************************************end//
$("body").on('click','#tabulatorConfig',function(){
    if($("input[name=tabulator]").length){
        var tabulator = $("input[name=tabulator]").val();
        var url = $('#globalTabulatorConfigModal .create-confg').attr('data-redirect');
        var href = url + '/' + tabulator;
        $('#globalTabulatorConfigModal .create-confg').attr('href', href);
        $('#globalTabulatorConfigModal').modal('show');
        
        var tabulatorStorage = $("input[name=tabulatorStorage]").val();
        $.ajax({
            type: "GET",
            url: window.location.origin + '/form-generator/public/getAllConfigurations/tabulator-' + tabulatorStorage,
            dataType: 'json',
            success: function( data ) {
                if(Object.keys(data).length > 0){
                    var ul = $("<ul>",{'class':'list-group'});
                    $.each(data, function(i, record){
                        var li = $("<li>",{'class':'list-group-item'});
                        var configUrl = window.location.origin + '/form-generator/public/tabulator-configurator/' + record.Id + '/edit';
                        
                        li.append(
                            record.configName,
                            '<a class="btn btn-sm btn-danger delete-configuration pull-right list2 " data-config-name="' + record.configName + '" data-config-id="' + record.Id + '"><i class="glyphicon glyphicon-trash"></i></a>', 
                            '<a class="btn btn-sm btn-primary pull-right list2" href="' + configUrl + '" style="margin-right: 10px;"><i class="glyphicon glyphicon-pencil"></i></a>',
                            '<a class="btn btn-sm btn-success show-configuration pull-right list2" data-config-name="' + record.configName + '" data-config-id="' + record.Id + '" style="margin-right: 10px;"><i class="glyphicon glyphicon-eye-open"></i></a>'
                        );
                        
                        ul.append(li);
                    });
                    $(".tabulator-configuration-list").html(ul);
                }else{
                    $(".tabulator-configuration-list").html('<div class="alert alert-info mt-10" role="alert"> No configuration created yet!</div>');
                }
            },
            beforeSend: function() {
                $(".tabulator-configuration-list").html('<div class="text-center"><i class="fa fa-spin fa-cog"></i> Loading...</div>');
            },
            complete: function() {
                
            }
        });
    }
});
$('body').on('click', '.delete-persistent', function(e){
    e.preventDefault();
    var tabulator = $("input[name=tabulatorStorage]").val();
    
    localStorage.removeItem('tabulator-' + tabulator);
    localStorage.removeItem('tabulator-' + tabulator + '1');
    localStorage.removeItem('tabulator-' + tabulator + '2');
    window.location.reload();
});

var tabulator = $("input[name=tabulator]").val();
var itemName = tabulator + 'Actions';
var responsiveText, responsive = localStorage.getItem(itemName);

if(responsive === null){
    var actionObj = {};
    actionObj['actions'] = true;
    actionObj['responsive'] = false;
    responsiveText = '<i class="fa fa-toggle-off"></i> Responsive Off';
}else{
    var actionObj = JSON.parse(responsive);
    actionObj['responsive'] = actionObj['responsive'] ? actionObj['responsive'] : false;
    responsive = actionObj['responsive'];
    responsiveText = (responsive) ? '<i class="fa fa-toggle-on"></i> Responsive On' : '<i class="fa fa-toggle-off"></i> Responsive Off';
}
localStorage.setItem(itemName, JSON.stringify(actionObj));
$("#toggle_responsive").html(responsiveText);
// change responsive layout
$("#toggle_responsive").on("click", function () {
    var tabulator = $("input[name=tabulator]").val();
    var itemName = tabulator + 'Actions';
    var actionObj = JSON.parse(localStorage.getItem(itemName));
    actionObj['responsive'] = actionObj['responsive'] ? false : true;
    localStorage.setItem(itemName, JSON.stringify(actionObj));    
    
    var responsiveText = (actionObj['responsive']) ? '<i class="fa fa-toggle-on"></i> Responsive On' : '<i class="fa fa-toggle-off"></i> Responsive Off';
    $("#toggle_responsive").html(responsiveText);
    $(".delete-persistent").click();
});

$('#pageActionModal').on('show.bs.modal', function (event) {
    var modal = $(this);
    if($('body #pageActions').length){
        var pageActions = $('#pageActions').clone();
        pageActions.find('.col-md-4, .col-lg-4, .float_right_class').removeClass('col-md-5 col-md-4 col-lg-4 float_right_class');
        pageActions.find('i.glyphicon').remove();
        modal.find('.modal-body .page-actions-list').html(pageActions);
        modal.find('.modal-body #pageActions').show();
        
        var tabulator = $("input[name=tabulator]").val();
    
        var itemName = tabulator + 'Actions';
        var actionStorage = localStorage.getItem(itemName);
        if(actionStorage === null){
            var actions = false;
        }else{
            var actionObj = JSON.parse(actionStorage);
            var actions = actionObj['actions'];
        }
        
        var buttonText = (actions) ? '<i class="fa fa-eye-slash"></i> Hide Actions' : '<i class="fa fa-eye"></i> Show Actions';
        modal.find('.toggle-actions').html(buttonText);
    }else{
        modal.find('.modal-body').html('<div class="alert alert-info" role="alert"> No page actions!</div>');
    }
});

$(document).on('click', '.toggle-actions', function(e){
    e.preventDefault();
    var tabulator = $("input[name=tabulator]").val();
    
    var itemName = tabulator + 'Actions';
    var actions = localStorage.getItem(itemName);
    
    if(actions === null){
        var actionObj = {};
        actionObj['actions'] = true;
        actionObj['icons'] = false;
    }else{
        var actionObj = JSON.parse(actions);
        actionObj['actions'] = actionObj['actions'] === true ? false : true;
    }

    localStorage.setItem(itemName, JSON.stringify(actionObj));

    if(!actionObj['actions']){
        $('.panel-body #pageActions, #form-records-page .table-controls').hide();
    }else{
        $('.panel-body #pageActions, #form-records-page .table-controls').show();
    }
    var buttonText = (actionObj['actions']) ? '<i class="fa fa-eye-slash"></i> Hide Actions' : '<i class="fa fa-eye"></i> Show Actions';
    $(this).html(buttonText);
    
    $('#pageActionModal').modal('hide');
});
$("body").on('click', '.rightbtn .show-page-actions', function(){
    var $arrow = $(this);
    $('.panel-body #pageActions, #form-records-page .table-controls').slideToggle('fast','linear',function(){
        $arrow.attr('title', 'Hide Page Actions');
        $arrow.removeClass('show-page-actions').addClass('hide-page-actions');
        $arrow.find('i').removeClass('glyphicon-chevron-down').addClass('glyphicon-chevron-up');
        
        var tabulator = $("input[name=tabulator]").val();
    
        var itemName = tabulator + 'Actions';
        var actions = localStorage.getItem(itemName);

        if(actions === null){
            var actionObj = {};
            actionObj['actions'] = true;
            actionObj['icons'] = false;
        }else{
            var actionObj = JSON.parse(actions);
            actionObj['actions'] = true;
        }

        localStorage.setItem(itemName, JSON.stringify(actionObj));
    });
});
$("body").on('click', '.rightbtn .hide-page-actions', function(){
    var $arrow = $(this);
    $('.panel-body #pageActions, #form-records-page .table-controls').slideToggle('fast','linear',function(){
        $arrow.attr('title', 'Show Page Actions');
        $arrow.addClass('show-page-actions').removeClass('hide-page-actions');
        $arrow.find('i').addClass('glyphicon-chevron-down').removeClass('glyphicon-chevron-up');
        
        var tabulator = $("input[name=tabulator]").val();
    
        var itemName = tabulator + 'Actions';
        var actions = localStorage.getItem(itemName);

        if(actions === null){
            var actionObj = {};
            actionObj['actions'] = false;
            actionObj['icons'] = false;
        }else{
            var actionObj = JSON.parse(actions);
            actionObj['actions'] = false;
        }

        localStorage.setItem(itemName, JSON.stringify(actionObj));
    });
});
$("body").on('click', '#pageActions .hide-actions-text', function(){
    var tabulator = $("input[name=tabulator]").val();    
    var itemName = tabulator + 'Actions';
    var actions = localStorage.getItem(itemName);
    
    if ($('#pageActions').find('[data-title]').length) {
        // Show text with icons
        $('#pageActions a.btn, #pageActions button[type=submit], #rearrange_btn a.btn, .table-controls > a.btn').each(function () {
            if ($(this).find('i').length) {
                var $i = $(this).find('i').detach();
                var txt = $.trim($(this).attr('data-title'));
                $(this).empty().append(
                        $i,
                        '&nbsp;',
                        txt
                        ).removeAttr('data-title');
            }
        });
        $('#pageActions button[name=group-rows]').each(function () {
            var $show = $(this).find('.show-rating'), $hide = $(this).find('.hide-rating');
            
            var $i1 = $show.find('i').detach(), txt1 = $.trim($show.attr('title'));
            var $i2 = $hide.find('i').detach(), txt2 = $.trim($hide.attr('title'));

            $show.empty().append(
                        $i1,
                        '&nbsp;',
                        txt1
                        ).removeAttr('title');
            $hide.empty().append(
                        $i2,
                        '&nbsp;',
                        txt2
                        ).removeAttr('title');
            
            $(this).removeAttr('data-title');
        });
        // For dropdown buttons
        $('#pageActions button.dropdown-toggle').each(function () {            
            var $i = $(this).find('i').detach(), txt = $.trim($(this).attr('title'));

            $(this).empty().append(
                        $i,
                        '&nbsp;',
                        txt,
                        '&nbsp;',
                        '<span class="caret"></span>'
                        ).removeAttr('data-title');
            $(this).removeAttr('title');
        });
        $(this).find('.glyphicon').removeClass('glyphicon-chevron-right').addClass('glyphicon-chevron-left');
        
        if(actions === null){
            var actionObj = {};
            actionObj['actions'] = true;
            actionObj['icons'] = false;
        }else{
            var actionObj = JSON.parse(actions);
            actionObj['icons'] = false;
        }
    } else {
        /* Hide Text to show icons only */
        // For simple buttons
        $('#pageActions a.btn, #pageActions button[type=submit], #rearrange_btn a.btn, .table-controls > a.btn').each(function () {
            if ($(this).find('i').length) {
                var $i = $(this).find('i').detach();
                var txt = $.trim($(this).text());
                $(this).attr({'title': txt, 'data-title': txt});
                $(this).empty().append($i);
            }
        });
        // For two icon buttons
        $('#pageActions button[name=group-rows]').each(function () {
            var $show = $(this).find('.show-rating'), $hide = $(this).find('.hide-rating');
            
            var $i1 = $show.find('i').detach(), txt1 = $.trim($show.text());
            var $i2 = $hide.find('i').detach(), txt2 = $.trim($hide.text());

            $show.attr({'title': txt1}); $show.empty().append($i1);
            $hide.attr({'title': txt2}); $hide.empty().append($i2);
            
            if ($(this).hasClass('col-hide')) {
                $(this).attr({'data-title': txt2});
            }else{
                $(this).attr({'data-title': txt1});
            }
        });
        // For dropdown buttons
        $('#pageActions button.dropdown-toggle').each(function () {            
            var $i = $(this).find('i').detach(), txt = $.trim($(this).text());

            $(this).attr({'title': txt, 'data-title': txt}); 
            $(this).empty().append($i);//$(this).append(' <span class="caret"></span>');
        });
        $(this).find('.glyphicon').removeClass('glyphicon-chevron-left').addClass('glyphicon-chevron-right');        

        if(actions === null){
            var actionObj = {};
            actionObj['actions'] = true;
            actionObj['icons'] = true;
        }else{
            var actionObj = JSON.parse(actions);
            actionObj['icons'] = true;
        }
    }
    localStorage.setItem(itemName, JSON.stringify(actionObj));
});

function initTabulator(elementID, options) {
    if (!elementID) {
        alert("Tabulator element is not set.");
    }

    var basicConfig = {
        layout: 'fitDataFill',
        tooltips: true,
        tooltipsHeader: true,
        movableColumns: true,
        responsiveLayout: false,
        //pagination:"local",
        //paginationSize:10,
    };

    var config = basicConfig;

    if (options !== '') {
        config = $.extend({}, basicConfig, options);
    }

    $("#" + elementID).tabulator(config);
}

//excel data showing
function xlsxChange(file,url){
    var data={};   
    var dataOutput={};
    var ajax = $(this).attr('data-xlsxfield');
    var file = (file !== undefined) ? file : '';
    var url = (url !== undefined) ? url : '';

    if(file.length > 0){
        $('input.inputClass').each(function(){
            var value="";
            if($(this).attr('data-xlsxfield')!= "" && $(this).val()!= ""){
                if($.inArray($(this).attr('type'), ["checkbox","radio"]) >= 0){
                    value = $(this).prop('checked');
                }else{
                    value=$(this).val();
                }
                var field = (typeof $(this).attr('data-xlsxfield') !=='undefined') ? $(this).attr('data-xlsxfield').toUpperCase() : '';
                var worksheet = (typeof $(this).attr('data-worksheet') !=='undefined') ? $(this).attr('data-worksheet') : '';
                data[field+'_'+worksheet]=value;
            }
        });
        $('input.disabledOutput').each(function(){
            var value=$(this).val();
            var field=(typeof $(this).attr('data-xlsxfield') !=='undefined') ? $(this).attr('data-xlsxfield').toUpperCase() : '';
            var worksheet = (typeof $(this).attr('data-worksheet') !=='undefined') ? $(this).attr('data-worksheet') : '';
            dataOutput[field+'_'+worksheet]=value;
        });
        var style =  'background-image: url('+url+'/../assets/images/input-loader.gif);background-size: 18px 18px;background-position: right center;background-repeat: no-repeat;';
        //console.log(url);
        $.ajax({
            url:url,
            data:{"input":data,'output':dataOutput,'file':file},
            beforeSend: function(){
                $.each(dataOutput, function(key, value){
                    key = key.split('_')[0];
                    $('input.disabledOutput[data-xlsxfield="'+key+'"]').attr('style',style);
//                    $('input.disabledOutput[data-xlsxfield="'+key+'"]').parents('.borderSet').block({ message: null });
                });
            },
            success:function(e){
                e=JSON.parse(e);
                if(e.code==="1"){
                    var data=e.value;
                    for(name in data){
                        var show = name.split('_');
                        var attrName = $('input.disabledOutput[data-xlsxfield="'+show[0]+'"][data-worksheet="'+show[1]+'"]').attr('name');
                        $('input.disabledOutput[data-xlsxfield="'+show[0]+'"][data-worksheet="'+show[1]+'"]').val(data[name]);
                        $('input.disabledOutput[data-xlsxfield="'+show[0]+'"][data-worksheet="'+show[1]+'"]').parent().append("<input type='hidden' name='"+attrName+"' value='"+data[name]+"'/>");
                        $('input.disabledOutput[data-xlsxfield="'+show[0]+'"]').removeAttr('style');
//                        $('input.disabledOutput[data-xlsxfield="'+show[0]+'"]').parents('.borderSet').unblock();
//                            OLD CODES
//                            var attrName=$('input.disabledOutput.'+name).attr('name');
//                            $('input.disabledOutput.'+name).val(data[name]);
//                            $('input.disabledOutput.'+name).parent().append("<input type='hidden' name='"+attrName+"' value='"+data[name]+"'/>");

                    }
                }
            },
            error:function(error){
                $.each(dataOutput, function(key, value){
                    key = key.split('_')[0];
                    $('input.disabledOutput[data-xlsxfield="'+key+'"]').parents('.borderSet').unblock();
                });
            },
            complete: function(){ }
        });
    }
}